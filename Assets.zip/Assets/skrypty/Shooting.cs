﻿using UnityEngine;
using System.Collections;
[RequireComponent(typeof(AudioSource))]

public class Shooting : MonoBehaviour {

	public Texture2D crosshairTexture;
	public AudioClip pistolShot;
	public AudioClip reloadSound;
	public int maxAmmo = 200;
	public int clipSize = 100;
	public GUIText ammoText;
	public GUIText reloadText;
	public float reloadTime = 3.0f;
	private int currentAmmo = 300;
	private int currentClip;
	private Rect position;   
	public float range ;
	public float mrange=100f ;
	private GameObject pistolSparks; 
	private Ray fwd;
	private RaycastHit hit;
	private bool isReloading = false;
	
	private float timer = 0.0f;


	// Use this for initialization
	void Start () {
		currentClip = clipSize;
		Screen.showCursor = false;
		position = new Rect((Screen.width - crosshairTexture.width) / 2,
		                    (Screen.height - crosshairTexture.height) /2,
		                    crosshairTexture.width,
		                    crosshairTexture.height);
		
		pistolSparks = GameObject.Find("Sparks");
		pistolSparks.particleEmitter.emit = false;
		audio.clip = pistolShot;
	}

	void OnGUI()
	{
		GUI.DrawTexture(position, crosshairTexture);
		ammoText.pixelOffset = new Vector2(-Screen.width / 2 + 100, -Screen.height / 2 + 30);
		ammoText.text = currentClip + " / " + currentAmmo;
		if(currentClip == 0) {
			reloadText.enabled = true;
		} else {
			reloadText.enabled = false;
		}
	}

	void Update () {
	//	Debug.DrawRay(transform.position, fwd, Color.green);
		fwd = Camera.main.ScreenPointToRay(new Vector3(Screen.width/2,Screen.height/2,0));
		if(((Input.GetButtonDown("Fire1") && currentClip == 0) || Input.GetButtonDown("Reload")) && currentClip < clipSize) {
			if(currentAmmo > 0) {
				audio.clip = reloadSound;
				audio.Play();
				isReloading = true;
			}
		}
		if(isReloading) {
			timer += Time.deltaTime;
			if(timer >= reloadTime) {
				int needAmmo = clipSize - currentClip;
				
				if(currentAmmo >= needAmmo) {
					currentClip = clipSize;
					currentAmmo -= needAmmo;
				} else {
					currentClip += currentAmmo;
					currentAmmo = 0;
				}
				
				audio.clip = pistolShot;
				isReloading = false;
				timer = 0.0f;
			}
		}

		if(Input.GetButtonDown("Fire1") && currentClip > 0 && !isReloading){
			currentClip--;
			pistolSparks.particleEmitter.Emit();
			audio.Play();
			if (Physics.Raycast(fwd, out hit,range)) {
				if(hit.collider.CompareTag ("Enemy") && mrange>hit.distance) {
					Debug.Log ("Trafiony przeciwnik");
				} else if(hit.collider.CompareTag("teren") && mrange>hit.distance) {
					Debug.Log ("Trafione otoczenie");
				}else{
					Debug.Log("kula sie rozpadla");
				}
			}else{
				Debug.Log("Poszlo w niebo");
			}
		}
	}
}
